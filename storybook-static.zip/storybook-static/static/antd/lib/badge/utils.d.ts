export declare function isPresetColor(color?: string): boolean;
