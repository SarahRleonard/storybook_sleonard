import Progress from './progress';
export { ProgressProps } from './progress';
export default Progress;
