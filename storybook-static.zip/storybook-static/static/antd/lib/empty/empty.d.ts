declare const Empty: () => JSX.Element;
export default Empty;
