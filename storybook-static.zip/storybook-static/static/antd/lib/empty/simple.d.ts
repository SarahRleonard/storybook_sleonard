declare const Simple: () => JSX.Element;
export default Simple;
