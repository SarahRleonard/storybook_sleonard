import daDK from '../../date-picker/locale/da_DK';
export default daDK;
