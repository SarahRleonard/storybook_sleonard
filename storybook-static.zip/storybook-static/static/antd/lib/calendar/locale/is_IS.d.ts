import isIS from '../../date-picker/locale/is_IS';
export default isIS;
