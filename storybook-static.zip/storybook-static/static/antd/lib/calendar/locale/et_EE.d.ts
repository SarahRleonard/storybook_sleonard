import etEE from '../../date-picker/locale/et_EE';
export default etEE;
