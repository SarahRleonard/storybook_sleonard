import knIN from '../../date-picker/locale/kn_IN';
export default knIN;
