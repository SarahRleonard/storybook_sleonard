import huHU from '../../date-picker/locale/hu_HU';
export default huHU;
