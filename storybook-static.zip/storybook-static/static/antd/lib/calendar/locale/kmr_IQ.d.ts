import kmrIQ from '../../date-picker/locale/kmr_IQ';
export default kmrIQ;
