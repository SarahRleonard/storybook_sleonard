import hiIN from '../../date-picker/locale/hi_IN';
export default hiIN;
