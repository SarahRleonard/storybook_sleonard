import fiFI from '../../date-picker/locale/fi_FI';
export default fiFI;
