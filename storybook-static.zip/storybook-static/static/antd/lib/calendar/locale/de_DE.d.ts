import deDE from '../../date-picker/locale/de_DE';
export default deDE;
