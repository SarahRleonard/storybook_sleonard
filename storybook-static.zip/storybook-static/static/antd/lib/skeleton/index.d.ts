import Skeleton from './Skeleton';
export { SkeletonProps } from './Skeleton';
export default Skeleton;
