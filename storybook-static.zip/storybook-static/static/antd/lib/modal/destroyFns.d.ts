declare const destroyFns: Array<() => void>;
export default destroyFns;
