declare const _default: "4.18.3";
export default _default;
