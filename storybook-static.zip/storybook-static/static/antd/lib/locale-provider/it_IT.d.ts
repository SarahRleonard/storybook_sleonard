import locale from '../locale/it_IT';
export default locale;
