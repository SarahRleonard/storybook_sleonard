import locale from '../locale/fr_CA';
export default locale;
