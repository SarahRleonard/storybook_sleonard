import locale from '../locale/ur_PK';
export default locale;
