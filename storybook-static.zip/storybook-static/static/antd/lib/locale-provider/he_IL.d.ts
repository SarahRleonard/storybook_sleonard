import locale from '../locale/he_IL';
export default locale;
