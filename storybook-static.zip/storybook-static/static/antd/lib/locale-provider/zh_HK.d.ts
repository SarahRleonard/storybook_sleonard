import locale from '../locale/zh_HK';
export default locale;
