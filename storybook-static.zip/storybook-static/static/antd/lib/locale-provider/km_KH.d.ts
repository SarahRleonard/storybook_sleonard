import locale from '../locale/km_KH';
export default locale;
