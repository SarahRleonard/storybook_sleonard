import locale from '../locale/az_AZ';
export default locale;
