import locale from '../locale/ml_IN';
export default locale;
