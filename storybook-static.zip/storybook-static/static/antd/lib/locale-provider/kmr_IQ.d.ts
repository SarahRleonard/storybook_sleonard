import locale from '../locale/kmr_IQ';
export default locale;
