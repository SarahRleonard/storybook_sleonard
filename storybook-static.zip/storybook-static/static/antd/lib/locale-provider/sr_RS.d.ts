import locale from '../locale/sr_RS';
export default locale;
