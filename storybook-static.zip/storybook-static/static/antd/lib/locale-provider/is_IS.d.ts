import locale from '../locale/is_IS';
export default locale;
