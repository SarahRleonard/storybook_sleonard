import locale from '../locale/ga_IE';
export default locale;
