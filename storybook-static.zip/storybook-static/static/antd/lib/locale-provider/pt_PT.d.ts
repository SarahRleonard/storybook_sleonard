import locale from '../locale/pt_PT';
export default locale;
