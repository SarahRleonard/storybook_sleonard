import locale from '../locale/lt_LT';
export default locale;
