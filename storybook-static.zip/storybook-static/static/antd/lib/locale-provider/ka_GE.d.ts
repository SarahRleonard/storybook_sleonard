import locale from '../locale/ka_GE';
export default locale;
