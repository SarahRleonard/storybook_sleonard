import locale from '../locale/ne_NP';
export default locale;
