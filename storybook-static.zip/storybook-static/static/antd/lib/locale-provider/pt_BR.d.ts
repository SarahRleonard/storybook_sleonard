import locale from '../locale/pt_BR';
export default locale;
