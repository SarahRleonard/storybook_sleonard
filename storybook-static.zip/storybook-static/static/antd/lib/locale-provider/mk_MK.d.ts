import locale from '../locale/mk_MK';
export default locale;
