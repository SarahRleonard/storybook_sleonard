import locale from '../locale/kk_KZ';
export default locale;
