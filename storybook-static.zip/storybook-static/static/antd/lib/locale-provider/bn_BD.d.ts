import locale from '../locale/bn_BD';
export default locale;
