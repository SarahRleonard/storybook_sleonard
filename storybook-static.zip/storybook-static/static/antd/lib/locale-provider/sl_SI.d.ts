import locale from '../locale/sl_SI';
export default locale;
