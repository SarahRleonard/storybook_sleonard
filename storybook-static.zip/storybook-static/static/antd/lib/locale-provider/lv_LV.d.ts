import locale from '../locale/lv_LV';
export default locale;
