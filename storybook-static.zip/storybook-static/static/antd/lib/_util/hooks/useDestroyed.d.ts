export default function useDestroyed(): () => boolean;
