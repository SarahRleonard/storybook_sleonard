import * as React from 'react';
export default function useForceUpdate(): React.DispatchWithoutAction;
