export declare function easeInOutCubic(t: number, b: number, c: number, d: number): number;
