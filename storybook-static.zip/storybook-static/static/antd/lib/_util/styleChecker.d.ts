import { isStyleSupport } from 'rc-util/lib/Dom/styleChecker';
export declare const canUseDocElement: () => false | HTMLElement;
export { isStyleSupport };
export declare const detectFlexGapSupported: () => boolean;
