export default class UnreachableException {
    error: Error;
    constructor(value: never);
}
