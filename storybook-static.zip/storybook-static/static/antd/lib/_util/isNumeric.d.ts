declare const isNumeric: (value: any) => boolean;
export default isNumeric;
