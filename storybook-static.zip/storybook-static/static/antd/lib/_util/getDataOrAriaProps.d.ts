export default function getDataOrAriaProps(props: any): any;
