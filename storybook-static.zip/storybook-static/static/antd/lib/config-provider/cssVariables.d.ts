import { Theme } from './context';
export declare function registerTheme(globalPrefixCls: string, theme: Theme): void;
