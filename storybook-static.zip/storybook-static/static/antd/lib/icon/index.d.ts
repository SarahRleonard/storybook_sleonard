declare const Icon: () => null;
export default Icon;
