import Collapse from './Collapse';
export { CollapseProps } from './Collapse';
export { CollapsePanelProps } from './CollapsePanel';
export default Collapse;
