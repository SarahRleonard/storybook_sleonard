import * as React from 'react';
import { RadioGroupProps } from './interface';
declare const _default: React.MemoExoticComponent<React.ForwardRefExoticComponent<RadioGroupProps & React.RefAttributes<HTMLDivElement>>>;
export default _default;
