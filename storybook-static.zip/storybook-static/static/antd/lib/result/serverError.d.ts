declare const ServerError: () => JSX.Element;
export default ServerError;
