declare const Unauthorized: () => JSX.Element;
export default Unauthorized;
