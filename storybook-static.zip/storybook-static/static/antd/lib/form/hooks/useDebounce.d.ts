export default function useDebounce<T>(value: T[]): T[];
