import * as React from 'react';
import { AntAnchor } from './Anchor';
declare const AnchorContext: React.Context<AntAnchor>;
export default AnchorContext;
