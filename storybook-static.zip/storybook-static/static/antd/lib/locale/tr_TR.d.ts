import { Locale } from '../locale-provider';
declare const localeValues: Locale;
export default localeValues;
